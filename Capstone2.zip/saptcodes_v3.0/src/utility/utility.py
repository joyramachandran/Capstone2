from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, LogonError, CommunicationError
from configparser import ConfigParser
from pprint import PrettyPrinter
import getpass

options = 0

def get_connection():
    """Get connection"""

    print ('Connecting ...', '10.47.41.47')
    abap_system = {
        'user': 'VIVEK',
        'passwd': 'Initial$1',
        'ashost': '10.47.41.47',
        'sysnr': '02',
        'client': '100',
        'trace': '3',  # optional, in case you want to trace
        'lang': 'EN'
    }
    return Connection(**abap_system)

def newsys():

    #print("new sys")

    desiredDict = {}
    ASHOST='10.47.41.47'
    CLIENT='100'
    SYSNR='01'
    USER='VIVEK'
    PASSWD='Initial$1'
    ASHOSTVal=input("Host IP Address\n")
    CLIENTVal=input("Client\n")
    SYSNRVal=input("System Number\n")
    USERVal=input("User\n")
    PASSWDVal = getpass.getpass('Password\n')

    ASHOSTVal = ASHOST
    CLIENTVal = CLIENT
    SYSNRVal = SYSNR
    USERVal = USER
    PASSWDVal = PASSWD
    desiredDict = {'ASHOST':ASHOSTVal,'CLIENT':CLIENTVal,'SYSNR':SYSNRVal,'USER':USERVal,'PASSWD':PASSWDVal}
    conn = Connection(ashost=desiredDict.get("ASHOST"), sysnr=desiredDict.get("SYSNR"), client=desiredDict.get("CLIENT"), user=desiredDict.get("USER"), passwd=desiredDict.get("PASSWD"))

    continueoption()
    
    


def currentsys():

    print("----System Details---")
    pp = PrettyPrinter(indent=4)
    print('ASHOST= ',desiredDict.get("ASHOST"))
    print('CLIENT= ',desiredDict.get("CLIENT"))
    print('SYSNR= ',desiredDict.get("SYSNR"))
    print('USER= ',desiredDict.get("USER"))

    continueoption()

def tableread():
        conn = Connection ;
        conn = get_connection()

        tableVal = input("Enter the table?\n")


        limit = int(input("Enter the no of fields"))
        c = 0
        dict_obj = None
        while c < limit:
            fieldVal = input("Enter the single fieldname?\n")
            Value = input("Enter the value for the field? ex:*,any text value\n")
            valueinput1 = "'" + Value + "'"
            valueinput = fieldVal + " = " + valueinput1
            valueDict = {'TEXT': valueinput}
            dict_obj.append(valueDict)
            c += 1
        #print(dict_obj)


        try:
            #options = [{ 'TEXT': "FCURR = 'USD'"}]
            options = [dict_obj]
            pp = PrettyPrinter(indent=4)
            ROWS_AT_A_TIME = 10
            rowskips = 0

            print("----Begin of Batch---")
            result = conn.call('RFC_READ_TABLE', \
            QUERY_TABLE = tableVal, \
            OPTIONS = options, \
            ROWSKIPS = rowskips, ROWCOUNT = ROWS_AT_A_TIME)
            pp.pprint(result['DATA'])

            rowskips += ROWS_AT_A_TIME

        except CommunicationError:
            print("Could not connect to server.")
            raise
        except LogonError:
            print("Could not log in. Wrong credentials?")
            raise
        except (ABAPApplicationError, ABAPRuntimeError):
            print("An error occurred.")
            raise


        continueoption()


func_dict = {'1' :newsys, '2' :currentsys,'3' :tableread}
def let_user_pick():

    
    options = ["Enter new system details", "Show the current system details", "Enter the table to read"]
    print("Please choose:")
    for idx, element in enumerate(options):
        print("{}) {}".format(idx+1,element))
    command = input("Enter number: ")
    
    try:
        if 0 < int(command) <= len(options):
            func_dict[command]()
            #return int(command)
           
    except:
        pass
        
    return None

def exitprg():
    exit()

func_dict1 = {'1' :let_user_pick, '2' :exitprg}
def continueoption():
    
    options1 = ["Do you want to continue with options further?", "do you want to exit?"]
    print("Please choose:")
    for idx, element in enumerate(options1):
        print("{}) {}".format(idx+1,element))
    command = input("Enter number: ")
    
    try:
        if 0 < int(command) <= len(options1):
            func_dict1[command]()
            #return int(command)
           
    except:
        pass
        
    return None